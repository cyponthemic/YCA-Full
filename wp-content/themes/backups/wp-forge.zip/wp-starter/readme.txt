WP-Starter
=======================================
A child theme for WP-Forge

Demo
=======================================
http://themeawesome.com/wpforge
(it looks and acts just like WP-Forge so no need to create another demo site)

Github
=======================================
https://github.com/tsquez/wp-starter

Author
=======================================
Thomas E. Vasquez (@tsquez)
http://themeawesome.com

License
=======================================
GPLv2 - http://www.gnu.org/licenses/gpl-2.0.html
Foundation by ZURB is MIT - http://opensource.org/licenses/MIT
