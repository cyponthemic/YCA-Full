WP-Forge
=======================================
Based off of Twenty Twelve, WP-Forge is a mixin' of two powerful platforms: WordPress, the universes leading open source blogging tool and content management system in the universe and Foundation 4.3.1, the most advanced responsive front-end framework in the multiverse.

Demo
=======================================
http://themeawesome.com/wpforge

Github
=======================================
https://github.com/tsquez/WP-Forge

Author
=======================================
Thomas E. Vasquez (@tsquez)
http://themeawesome.com

Additional Credits - I used various functions from different themes built with WordPress and Foundation
=======================================
Zhen Huang - Reverie Theme (http://themefortress.com/reverie/)

320Press - WordPress Foundation (https://github.com/320press/wordpress-foundation)

required+ - Required-Foundation (https://github.com/wearerequired/required-foundation)

License
=======================================
GPLv2 - http://www.gnu.org/licenses/gpl-2.0.html
Foundation by ZURB is MIT - http://opensource.org/licenses/MIT
