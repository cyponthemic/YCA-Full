jQuery(document).ready(function() {

	/* Mobile Menu --- */
	jQuery('.mobile-nav-toggle').click(function(e) {
		e.preventDefault();
		jQuery('body').toggleClass('mobile-nav-active');
	});


	/* Grid Isotope --- */
	var $gridContainer = jQuery('.primary-grid'),
		$filter = jQuery('.primary-filter');
	$gridContainer.isotope({
		itemSelector : 'li'
	});
	jQuery(window).smartresize(function(){
		$gridContainer.isotope( 'reLayout' );
	});

	$filter.find('a').click(function(e){
		e.preventDefault();
		$gridContainer.isotope({ filter: jQuery(this).attr('data-filter') });
		$filter.find('a').removeClass('selected');
		jQuery(this).addClass('selected');
	});


	/* Infinite Scrolling --- */
	var content = '.infinite-content',
		grid = '.infinite-grid',
		nav = '.infinite-pagination',
		loadingArray = {
			selector: ".load-more",
			img: "",
			finishedMsg: "<span>You've reached the end.</span>",
			msgText: "<div class=\"spinner\"><div class=\"mask\"><div class=\"maskedCircle\"></div></div></div>Loading ...",
		};
		
	jQuery(content).infinitescroll({
		navSelector: nav,
		nextSelector: nav+" a:last",
		itemSelector: content+" .post",
		prefill: true,
		bufferPx: 80,
		loading: loadingArray
	}, function(e){
		jQuery(e).hide().slideDown();
	});
	jQuery(grid).infinitescroll({
		navSelector: nav,
		nextSelector: nav+" a:last",
		itemSelector: grid+">li",
		prefill: true,
		bufferPx: 80,
		loading: loadingArray
	}, function(e){
		var length = e.length, elements = "";
		elements = jQuery(e).clone().wrap('div');
		jQuery(e).remove();
		$gridContainer.isotope('insert', elements);
	});
	jQuery(nav).hide();
});
