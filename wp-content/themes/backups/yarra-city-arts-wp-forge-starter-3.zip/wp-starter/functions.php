<?php
/**
 * WP-Starter functions and definitions.
 *
 * A blank functions.php file to add your own functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development and
 * http://codex.wordpress.org/Child_Themes), you can override certain functions
 * (those wrapped in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before the parent
 * theme's file, so the child theme functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are instead attached
 * to a filter or action hook.
 *
 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
 *
 * @package WordPress
 * @subpackage WP_Starter
 * @since WP-Starter 1.0
 */

/**
 * Includes
 */
// OptionTree
add_filter( 'ot_show_pages', '__return_false' );
add_filter( 'ot_show_new_layout', '__return_false' );
add_filter( 'ot_theme_mode', '__return_true' );
add_filter( 'ot_child_theme_mode', '__return_true' );
load_template( trailingslashit( get_stylesheet_directory() ) . 'option-tree/ot-loader.php' );
// ACF
define( 'ACF_LITE', true );
include_once('advanced-custom-fields/acf.php');
// CPT & Options
load_template( trailingslashit( get_stylesheet_directory() ) . 'inc/custom-post-types.php');
load_template( trailingslashit( get_stylesheet_directory() ) . 'inc/meta-boxes.php');
load_template( trailingslashit( get_stylesheet_directory() ) . 'inc/theme-options.php');

/**
 * Setup WP-Starter Theme's textdomain.
 *
 * Declare textdomain for this child theme.
 * Translations can be filed in the /languages/ directory.
 */
function wpstarter_theme_setup() {
	load_child_theme_textdomain( 'wpstarter', get_stylesheet_directory() . '/language' );

	remove_editor_styles();
	add_editor_style( array( 'css/foundation.min.css', 'style.css', 'fonts/font-awesome.css' ) );

	add_image_size( 'thumb', 500, 347, true );
	add_image_size( 'thumb2', 600, 320, true );
	add_image_size( 'full', 1200, 380, true );
	add_image_size( 'long', 600, 870, true );
}
add_action( 'after_setup_theme', 'wpstarter_theme_setup', 99 );

/**
 * Remove Theme Supports for the Child.
 */
function wpstarter_remove_support_child() {
	remove_theme_support( 'post-formats' );
	remove_theme_support( 'custom-header' );
	remove_theme_support( 'custom-background' );
}
add_action( 'after_setup_theme', 'wpstarter_remove_support_child', 11 );

/**
 * Scripts & Styles
 */
function wpstarter_scripts_styles() {
	wp_enqueue_script( 'isotope-js', get_stylesheet_directory_uri() . '/js/isotope.min.js', array('foundation-js'), '', true );
	wp_enqueue_script( 'infinite-scroll-js', get_stylesheet_directory_uri() . '/js/infinite-scroll.min.js', array('foundation-js'), '', true );
	wp_enqueue_script( 'app-js', get_stylesheet_directory_uri() . '/js/app.js', array('functions-js'), '', true );

	wp_dequeue_style( 'normalize' );
	wp_enqueue_style( 'foundation', get_template_directory_uri() . '/css/foundation.min.css' );

	global $is_IE, $wp_styles, $wp_scripts;
	if($is_IE) {
		wp_enqueue_script( 'selectivizr', get_stylesheet_directory_uri() . '/js/selectivizr.min.js' );
		wp_enqueue_style( 'ie8-css', get_stylesheet_directory_uri() . '/css/ie8.css' );
		$wp_styles->add_data( 'ie8-css', 'conditional', 'lt IE 9' );
		$wp_scripts->add_data( 'selectivizr', 'conditional', 'lt IE 9' );
	}
}
add_action( 'wp_enqueue_scripts', 'wpstarter_scripts_styles', 11 );

/**
 * Sidebar
 */
function wpstarter_widgets_init() {
	unregister_sidebar( 'sidebar-2' );
	unregister_sidebar( 'sidebar-3' );

	register_sidebar( array(
		'name' => __( 'Resources Sidebar', 'wpforge' ),
		'id' => 'sidebar-2',
		'description' => __( 'Displays widgets in the blog area as well as pages.', 'wpforge' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<h4 class="widget-title">',
		'after_title' => '</h4>',
	) );
}
add_action( 'widgets_init', 'wpstarter_widgets_init', 11 );


//Excerpt
function custom_excerpt_length( $length ) { return 17; }
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
function new_excerpt_more( $more ) { return '...'; }
add_filter('excerpt_more', 'new_excerpt_more');

/* URL Functions */
?>